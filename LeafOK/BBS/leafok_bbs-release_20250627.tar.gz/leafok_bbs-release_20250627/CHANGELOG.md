# ChangeLog of LeafOK BBS

Copyright (C) LeafOK.com, 2001-2025

https://www.leafok.com

2025-06
=================
DB schema change for LBBS (terminal server version)  
Minor enhancement and bug fix

2025-04
=================
Replace MyISAM storage engine with InnoDB  
Use UTF-8 instead of GBK in both data and web pages  
Seperate backend logic and web view for major features  
Add user TZ setting  
Add theme support for major features  
Many feature enhancement and bug fix  

2025-02
=================
Purge Innbbsd related data and programs  
Purge BBSViewer related programs (both server and client)  

2003-08
=================
Add Innbbsd, which provides INN transport features between LeafOK BBS and INND service.  

2003-05
=================
Add BBSViewer, a Windows desktop application for viewing the posts.  

2001-01
=================
Initial version of LeafOK BBS, a web-based BBS  
