<?php
	$DB_hostname			=	"127.0.0.1";
	$DB_username			=	"leafok";
	$DB_password			=	"123456";
	$DB_database			=	"leafok";

	$DB_session_timezone	=	"+08:00"; //Keep consistent with DB server config
