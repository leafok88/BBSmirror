<?php
	$Mail_Type = "SMTP";
	$Mail_Server = "localhost";
	$Mail_Server_Port = 25;
	$Mail_Auth = true;
	$Mail_User = "root@localhost";
	$Mail_Pass = "123456";
	$Mail_Sender = "root@localhost";
